﻿namespace Technician_IOOP
{
    partial class ViewServiceRequested
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTypeofService = new System.Windows.Forms.Label();
            this.lblProblemDescription = new System.Windows.Forms.Label();
            this.lblPickUpDate = new System.Windows.Forms.Label();
            this.txtService = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.dtpPickupDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnExit.Location = new System.Drawing.Point(529, 525);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 59);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnUpdate.Location = new System.Drawing.Point(234, 525);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(149, 59);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "Update Service Description";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(315, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(351, 44);
            this.lblTitle.TabIndex = 7;
            this.lblTitle.Text = "Service Requested";
            // 
            // lblTypeofService
            // 
            this.lblTypeofService.AutoSize = true;
            this.lblTypeofService.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTypeofService.Location = new System.Drawing.Point(59, 177);
            this.lblTypeofService.Name = "lblTypeofService";
            this.lblTypeofService.Size = new System.Drawing.Size(221, 34);
            this.lblTypeofService.TabIndex = 13;
            this.lblTypeofService.Text = "Type of Service";
            // 
            // lblProblemDescription
            // 
            this.lblProblemDescription.AutoSize = true;
            this.lblProblemDescription.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblProblemDescription.Location = new System.Drawing.Point(61, 253);
            this.lblProblemDescription.Name = "lblProblemDescription";
            this.lblProblemDescription.Size = new System.Drawing.Size(289, 34);
            this.lblProblemDescription.TabIndex = 15;
            this.lblProblemDescription.Text = "Problem Description";
            // 
            // lblPickUpDate
            // 
            this.lblPickUpDate.AutoSize = true;
            this.lblPickUpDate.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPickUpDate.Location = new System.Drawing.Point(59, 416);
            this.lblPickUpDate.Name = "lblPickUpDate";
            this.lblPickUpDate.Size = new System.Drawing.Size(191, 34);
            this.lblPickUpDate.TabIndex = 14;
            this.lblPickUpDate.Text = "Pick Up Date";
            // 
            // txtService
            // 
            this.txtService.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtService.Location = new System.Drawing.Point(365, 173);
            this.txtService.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtService.Name = "txtService";
            this.txtService.Size = new System.Drawing.Size(233, 41);
            this.txtService.TabIndex = 17;
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtDescription.Location = new System.Drawing.Point(366, 249);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(231, 41);
            this.txtDescription.TabIndex = 19;
            // 
            // cmbService
            // 
            this.cmbService.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Location = new System.Drawing.Point(61, 111);
            this.cmbService.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(172, 28);
            this.cmbService.TabIndex = 20;
            this.cmbService.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblStatus.Location = new System.Drawing.Point(61, 327);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(96, 34);
            this.lblStatus.TabIndex = 21;
            this.lblStatus.Text = "Status";
            // 
            // txtStatus
            // 
            this.txtStatus.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtStatus.Location = new System.Drawing.Point(366, 323);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(231, 41);
            this.txtStatus.TabIndex = 22;
            // 
            // dtpPickupDate
            // 
            this.dtpPickupDate.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtpPickupDate.Location = new System.Drawing.Point(365, 409);
            this.dtpPickupDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpPickupDate.Name = "dtpPickupDate";
            this.dtpPickupDate.Size = new System.Drawing.Size(233, 41);
            this.dtpPickupDate.TabIndex = 23;
            // 
            // ViewServiceRequested
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.dtpPickupDate);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.cmbService);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtService);
            this.Controls.Add(this.lblProblemDescription);
            this.Controls.Add(this.lblPickUpDate);
            this.Controls.Add(this.lblTypeofService);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ViewServiceRequested";
            this.Text = "View Service Requested";
            this.Load += new System.EventHandler(this.ViewServiceRequested_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnExit;
        private Button btnUpdate;
        private Label lblTitle;
        private Label lblTypeofService;
        private Label lblProblemDescription;
        private Label lblPickUpDate;
        private TextBox txtService;
        private TextBox txtDescription;
        private ComboBox cmbService;
        private Label lblStatus;
        private TextBox txtStatus;
        private DateTimePicker dtpPickupDate;
    }
}