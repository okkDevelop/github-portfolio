﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupAssignment
{
    public partial class ServiceDetails : Form
    {
        public static string name;
        public ServiceDetails()
        {
            InitializeComponent();
        }

        public ServiceDetails(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void ServiceDetails_Load(object sender, EventArgs e)
        {
            Customer2 obj1 =  new Customer2(name);
            Customer2.ViewService(obj1);
            lblOrderID.Text = obj1.OrderID;
            txtService.Text = obj1.Service;
            lblPrice.Text = obj1.Price;
            lblDescription.Text = obj1.Description;
            lblPickupDate.Text = obj1.PickupDate.ToString();
            txtUrgency.Text = obj1.Urgency;

            // if the cutomer don't have the service order in record, it will not shown the button for change the service. 
            if (lblOrderID.Text == String.Empty)
            {
                btnchange.Visible = false;
                btnConfirm.Visible = false;
                btnCancel.Visible = false;
            }
            //if the cutomer has the service on record, it will the button for customer to change the service.
            else
            {
                btnchange.Visible = true;
                btnConfirm.Visible = false;
                btnCancel.Visible = false;
            }
        }

        private void btnchange_Click(object sender, EventArgs e)
        {
            //if the customer click the button if will show the cancel button, confirm button ad warning.
            btnCancel.Visible = true;
            btnConfirm.Visible = true;
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            // When the customer click on this button, it will not shown the warning and the confirm button
            btnCancel.Visible = false;
            btnConfirm.Visible = false;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            // update the service
            Customer2 obj1 = new Customer2(name);
            MessageBox.Show(obj1.ServiceChange(txtService.Text, txtUrgency.Text, lblPrice.Text));
        }
    }
}
