﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class ReceptionistMenu : Form
    {
        private string loggedUser;
        public ReceptionistMenu()
        {
            InitializeComponent();
        }

        public ReceptionistMenu(string user)
        {
            InitializeComponent();
            loggedUser = user;
        }

        private void btnService_Click(object sender, EventArgs e) //this is the Register Button
        {
            this.Hide();
            RegisterPage g = new RegisterPage(loggedUser);
            g.ShowDialog();
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateProfile d = new UpdateProfile(loggedUser);
            d.ShowDialog();
            this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e) //this is the Payment Button
        {
            this.Hide();
            Payment f = new Payment(loggedUser);
            f.ShowDialog();
            this.Close();
        }

        private void btnRecords_Click(object sender, EventArgs e) //this is the Request Service
        {
            this.Hide();
            OrderService c = new OrderService(loggedUser);
            c.ShowDialog();
            this.Close();
        }

        private void BackLogin_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ReceptionistMenu_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome, " + loggedUser;
        }
    }
}
