﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class Payment : Form
    {
        private string loggedUserID;
        public Payment()
        {
            InitializeComponent();
        }

        public Payment(string u)
        {
            InitializeComponent();
            loggedUserID = u;
        }

        private void payment(object sender, EventArgs e)
        {
            ArrayList OrderID = new ArrayList();
            Service obj1 = new Service();
            OrderID = obj1.viewAllOrderID();
            foreach (var item in OrderID)
                cbSeviceID.Items.Add(item);
            

        }
        private void btnCancel3_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
            a.ShowDialog();
            this.Close();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            DateTime Date = DateTime.Now;
            if (cbSeviceID.SelectedIndex != -1)
            {
                Service obj1 = new Service();
                string status = obj1.payService(cbSeviceID.Text);
                MessageBox.Show(status + "\n" + "Paid at" + Date + "\n" + lblDetail.Text + "\n" + lblDetailInform.Text);
                this.Hide();
                ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                a.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Error");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Service obj1 = new Service();
            string CustomerID = obj1.findCustomer(cbSeviceID.SelectedItem.ToString());
            string name = CustomerID;
            string Email = obj1.viewinform(CustomerID, "Email");
            string Phone = obj1.viewinform(CustomerID, "Phone");
            lblDetail.Text = "UserName: " + name + "\nEmail: " + Email + "\nPhone: " + Phone;

            string ServiceType = obj1.viewServiceDetail(cbSeviceID.SelectedItem.ToString(), "Service");
            string Description = obj1.viewServiceDetail(cbSeviceID.SelectedItem.ToString(), "Description");
            string FinalCost = obj1.viewServiceDetail(cbSeviceID.SelectedItem.ToString(), "Price");
            lblDetailInform.Text = "Service:\n" + ServiceType + "\nDescription:\n" + Description + "\nFinalCost: RM" + FinalCost;

        }

        private void Payment_Load(object sender, EventArgs e)
        {
            ArrayList ServiceID = new ArrayList();
            Service obj1 = new Service();
            ServiceID = obj1.viewAllOrderID();
            foreach (var item in ServiceID)
                cbSeviceID.Items.Add(item);
        }
    }
}
