﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace admin_assignment
{
    public partial class Register_Receptionist : Form
    {
        public Register_Receptionist()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void txtBoxTelephone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void lblTelephone_Click(object sender, EventArgs e)
        {

        }

        private void Register_Receptionist_Load(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //validation for the user to fill in the correct password
            if (txtPassword.Text == txtComfirm.Text)
            {
                //set the validation if the user doesn't fill in the form
                if (txtName.Text == "" || txtEmail.Text == "" || txtTelephone.Text == "" || txtUN.Text == "" || txtPassword.Text == "" || txtComfirm.Text == "")
                {
                    MessageBox.Show("Please complete your form");
                }
                else 
                {
                    //validation for avoid user to key in others sign
                    if (Regex.IsMatch(txtEmail.Text, @"^[a-z A-Z 0-9 _ @ .]+$") && txtEmail.Text.EndsWith("mail.com"))
                    {
                        //validation for user to key in the correct phone number
                        if (Regex.IsMatch(txtTelephone.Text, @"^[0-9 -]+$") && txtTelephone.TextLength == 11)
                        {
                            //call the method and set the arguement
                            Register obj1 = new Register(txtName.Text, txtUN.Text, txtPassword.Text, txtEmail.Text, txtTelephone.Text);
                            MessageBox.Show(obj1.add_Receptionist());
                            //empty the text box for fill in next user details conveniently
                            txtName.Text = string.Empty;
                            txtEmail.Text = string.Empty;
                            txtTelephone.Text = string.Empty;
                            txtUN.Text = string.Empty;
                            txtPassword.Text = string.Empty;
                            txtComfirm.Text = string.Empty;

                        }
                        else 
                        {
                            txtTelephone.Clear();
                            MessageBox.Show("Invalid phone number input");
                        }
                    }
                    else 
                    {
                        txtEmail.Clear();
                        MessageBox.Show("Invalid email input");
                    }
                }
            }
            else 
            {
                MessageBox.Show("your password doesn't match");
                txtPassword.Text = string.Empty;
                txtComfirm.Text = string.Empty;
            }
        }
    }
}
