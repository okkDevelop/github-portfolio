﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class RegisterPage : Form
    {
        private string loggedUserID;

        public RegisterPage()
        {
            InitializeComponent();
        }

        public RegisterPage(string u)
        {
            InitializeComponent();
            loggedUserID = u;
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string name = txtUser.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            if (name != "")
            {
                if (email != "" && txtEmail.Text.Contains("@"))
                {
                    if (phone != "" && int.TryParse(txtPhone.Text, out int numericValue))
                    {
                        this.Hide();
                        Customer obj1 = new Customer(name, txtEmail.Text, txtPhone.Text);
                        MessageBox.Show(obj1.RegisterNewCustomer());
                        OrderService a = new OrderService(loggedUserID);
                        a.ShowDialog();
                        this.Close();
                    }
                    else 
                    {
                        MessageBox.Show("Invalid Error or Incorrect Phone number Input");
                    }
                }
                else 
                {
                    MessageBox.Show("Invalid Error or Incorrect Email Input");
                }
            }
            else
            {
                MessageBox.Show("Invalid Error");
            }
                
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
            a.ShowDialog();
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUser.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
        }

        private void RegisterPage_Load(object sender, EventArgs e)
        {

        }
    }
}
