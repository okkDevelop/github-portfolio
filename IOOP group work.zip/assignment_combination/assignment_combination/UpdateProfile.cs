﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class UpdateProfile : Form
    {
        private string loggedUserID = "";
        private string CurrentName = "";
        private string CurrentPassword = "";
        private string CurrentEmail = "";
        private string CurrentPhone = "";
        private string NewName = "";
        private string NewPassword = "";
        private string NewEmail = "";
        private string NewPhone = "";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public UpdateProfile(string u)
        {
            InitializeComponent();
            loggedUserID = u;
        }

        private void EditProfile(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select name from Receptionist where userID ='" + loggedUserID + "'", con);
            CurrentName = cmd1.ExecuteScalar().ToString();
            SqlCommand cmd2 = new SqlCommand("select phone_number from Receptionist where userID ='" + loggedUserID + "'", con);
            CurrentPhone = cmd2.ExecuteScalar().ToString();
            SqlCommand cmd3 = new SqlCommand("select Email from Receptionist where userID ='" + loggedUserID + "'", con);
            CurrentEmail = cmd3.ExecuteScalar().ToString();
            SqlCommand cmd4 = new SqlCommand("select password from Receptionist where userID ='" + loggedUserID + "'", con);
            CurrentPassword = cmd4.ExecuteScalar().ToString();
            con.Close();

            NewPassword = CurrentPassword;
            NewEmail = CurrentEmail;   
            NewPhone = CurrentPhone;

            //lblCurrentDetails.Text = "UserID: " + loggedUserID + "\nname: " + CurrentName + "\nEmail: " + CurrentEmail + "\npChone_number: " + CurrentPhone;
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            string pass = txtPassword2.Text;
            string phone = txtPhone.Text;
            string email = txtEmail.Text;
            if (pass != "")
            {
                if (phone != "" && int.TryParse(txtPhone.Text, out int numericValue))
                {
                    if (email != "" && txtEmail.Text.Contains("@"))
                    {
                        this.Hide();
                        con.Open();
                        SqlCommand cmd = new SqlCommand("update Receptionist set Email = '" + txtEmail.Text + "', phone_number = '" + txtPhone.Text + "', password = '" + txtPassword2.Text + "' where userID = '" + loggedUserID + "'", con);
                        SqlCommand cmd2 = new SqlCommand("update UserData set Password = '" + txtPassword2.Text + "' where UserName = '" + loggedUserID + "'", con);
                        int i = cmd.ExecuteNonQuery();
                        int i2 = cmd2.ExecuteNonQuery();
                        if ((i != 0) && (i2 != 0))
                        {
                            MessageBox.Show("Status Updated");
                        }
                        else
                        {
                            MessageBox.Show("Status Failed to Update");
                        }
                        con.Close();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Error");
                    }
                }
                else 
                {
                    MessageBox.Show("Invalid Error or Incorrect Phone number Input");
                }
            }
            else
            {
                MessageBox.Show("Invalid Error");
            }
        }

        private void btnBack2_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
            a.ShowDialog();
            this.Close();
        }

        private void UpdateProfile_Load(object sender, EventArgs e)
        {
            Customer obj1 = new Customer(loggedUserID);
            string Name = obj1.viewReceptionistDetail("name");
            string Email = obj1.viewReceptionistDetail("Email");
            string Phone = obj1.viewReceptionistDetail("phone_number");
            lblCurrentDetails.Text = "UserID: " + loggedUserID + "\nName: " + Name + "\nEmail: " + Email + "\nPhone: " + Phone;
        }

        private void lblCurrentDetails_Click(object sender, EventArgs e)
        {

        }
    }
}
