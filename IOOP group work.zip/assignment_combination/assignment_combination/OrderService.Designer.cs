﻿namespace Assignment
{
    partial class OrderService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblT4 = new System.Windows.Forms.Label();
            this.GroupService = new System.Windows.Forms.GroupBox();
            this.radioBtn8 = new System.Windows.Forms.RadioButton();
            this.radioBtn7 = new System.Windows.Forms.RadioButton();
            this.radioBtn6 = new System.Windows.Forms.RadioButton();
            this.radioBtn5 = new System.Windows.Forms.RadioButton();
            this.radioBtn4 = new System.Windows.Forms.RadioButton();
            this.radioBtn2 = new System.Windows.Forms.RadioButton();
            this.radioBtn3 = new System.Windows.Forms.RadioButton();
            this.radioBtn1 = new System.Windows.Forms.RadioButton();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel2 = new System.Windows.Forms.Button();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.RadioNormal = new System.Windows.Forms.RadioButton();
            this.RadioUrgent = new System.Windows.Forms.RadioButton();
            this.cbUserID = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.UserDetail = new System.Windows.Forms.Label();
            this.GroupService.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblT4
            // 
            this.lblT4.AutoSize = true;
            this.lblT4.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblT4.Location = new System.Drawing.Point(305, 9);
            this.lblT4.Name = "lblT4";
            this.lblT4.Size = new System.Drawing.Size(164, 49);
            this.lblT4.TabIndex = 5;
            this.lblT4.Text = "Service";
            // 
            // GroupService
            // 
            this.GroupService.Controls.Add(this.radioBtn8);
            this.GroupService.Controls.Add(this.radioBtn7);
            this.GroupService.Controls.Add(this.radioBtn6);
            this.GroupService.Controls.Add(this.radioBtn5);
            this.GroupService.Controls.Add(this.radioBtn4);
            this.GroupService.Controls.Add(this.radioBtn2);
            this.GroupService.Controls.Add(this.radioBtn3);
            this.GroupService.Controls.Add(this.radioBtn1);
            this.GroupService.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.GroupService.Location = new System.Drawing.Point(35, 90);
            this.GroupService.Name = "GroupService";
            this.GroupService.Size = new System.Drawing.Size(386, 338);
            this.GroupService.TabIndex = 17;
            this.GroupService.TabStop = false;
            this.GroupService.Text = "Service Type";
            // 
            // radioBtn8
            // 
            this.radioBtn8.AutoSize = true;
            this.radioBtn8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn8.Location = new System.Drawing.Point(40, 286);
            this.radioBtn8.Name = "radioBtn8";
            this.radioBtn8.Size = new System.Drawing.Size(228, 24);
            this.radioBtn8.TabIndex = 31;
            this.radioBtn8.TabStop = true;
            this.radioBtn8.Text = "Internet connectivity issues";
            this.radioBtn8.UseVisualStyleBackColor = true;
            this.radioBtn8.CheckedChanged += new System.EventHandler(this.radioBtn8_CheckedChanged);
            // 
            // radioBtn7
            // 
            this.radioBtn7.AutoSize = true;
            this.radioBtn7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn7.Location = new System.Drawing.Point(40, 252);
            this.radioBtn7.Name = "radioBtn7";
            this.radioBtn7.Size = new System.Drawing.Size(232, 24);
            this.radioBtn7.TabIndex = 30;
            this.radioBtn7.TabStop = true;
            this.radioBtn7.Text = "Data backup and recovery";
            this.radioBtn7.UseVisualStyleBackColor = true;
            this.radioBtn7.CheckedChanged += new System.EventHandler(this.radioBtn7_CheckedChanged);
            // 
            // radioBtn6
            // 
            this.radioBtn6.AutoSize = true;
            this.radioBtn6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn6.Location = new System.Drawing.Point(40, 215);
            this.radioBtn6.Name = "radioBtn6";
            this.radioBtn6.Size = new System.Drawing.Size(327, 24);
            this.radioBtn6.TabIndex = 30;
            this.radioBtn6.TabStop = true;
            this.radioBtn6.Text = "Operating System Format and Installation";
            this.radioBtn6.UseVisualStyleBackColor = true;
            this.radioBtn6.CheckedChanged += new System.EventHandler(this.radioBtn6_CheckedChanged);
            // 
            // radioBtn5
            // 
            this.radioBtn5.AutoSize = true;
            this.radioBtn5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn5.Location = new System.Drawing.Point(40, 177);
            this.radioBtn5.Name = "radioBtn5";
            this.radioBtn5.Size = new System.Drawing.Size(238, 24);
            this.radioBtn5.TabIndex = 30;
            this.radioBtn5.TabStop = true;
            this.radioBtn5.Text = "Laptop battery replacement";
            this.radioBtn5.UseVisualStyleBackColor = true;
            this.radioBtn5.CheckedChanged += new System.EventHandler(this.radioBtn5_CheckedChanged);
            // 
            // radioBtn4
            // 
            this.radioBtn4.AutoSize = true;
            this.radioBtn4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn4.Location = new System.Drawing.Point(40, 141);
            this.radioBtn4.Name = "radioBtn4";
            this.radioBtn4.Size = new System.Drawing.Size(256, 24);
            this.radioBtn4.TabIndex = 30;
            this.radioBtn4.TabStop = true;
            this.radioBtn4.Text = "Laptop keyboard replacement";
            this.radioBtn4.UseVisualStyleBackColor = true;
            this.radioBtn4.CheckedChanged += new System.EventHandler(this.radioBtn4_CheckedChanged);
            // 
            // radioBtn2
            // 
            this.radioBtn2.AutoSize = true;
            this.radioBtn2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn2.Location = new System.Drawing.Point(40, 70);
            this.radioBtn2.Name = "radioBtn2";
            this.radioBtn2.Size = new System.Drawing.Size(335, 24);
            this.radioBtn2.TabIndex = 28;
            this.radioBtn2.TabStop = true;
            this.radioBtn2.Text = "Troubleshot and fix computer running slow";
            this.radioBtn2.UseVisualStyleBackColor = true;
            this.radioBtn2.CheckedChanged += new System.EventHandler(this.radioBtn2_CheckedChanged);
            // 
            // radioBtn3
            // 
            this.radioBtn3.AutoSize = true;
            this.radioBtn3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn3.Location = new System.Drawing.Point(40, 106);
            this.radioBtn3.Name = "radioBtn3";
            this.radioBtn3.Size = new System.Drawing.Size(235, 24);
            this.radioBtn3.TabIndex = 28;
            this.radioBtn3.TabStop = true;
            this.radioBtn3.Text = "Laptop screen replacement";
            this.radioBtn3.UseVisualStyleBackColor = true;
            this.radioBtn3.CheckedChanged += new System.EventHandler(this.radioBtn3_CheckedChanged);
            // 
            // radioBtn1
            // 
            this.radioBtn1.AutoSize = true;
            this.radioBtn1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radioBtn1.Location = new System.Drawing.Point(40, 34);
            this.radioBtn1.Name = "radioBtn1";
            this.radioBtn1.Size = new System.Drawing.Size(288, 24);
            this.radioBtn1.TabIndex = 28;
            this.radioBtn1.TabStop = true;
            this.radioBtn1.Text = "Remove virus, malware or spyware";
            this.radioBtn1.UseVisualStyleBackColor = true;
            this.radioBtn1.CheckedChanged += new System.EventHandler(this.radioBtn1_CheckedChanged);
            // 
            // btnOk
            // 
            this.btnOk.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOk.Location = new System.Drawing.Point(456, 364);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(121, 60);
            this.btnOk.TabIndex = 15;
            this.btnOk.Text = "ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel2
            // 
            this.btnCancel2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCancel2.Location = new System.Drawing.Point(613, 366);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(118, 56);
            this.btnCancel2.TabIndex = 18;
            this.btnCancel2.Text = "Back";
            this.btnCancel2.UseVisualStyleBackColor = true;
            this.btnCancel2.Click += new System.EventHandler(this.btnCancel2_Click);
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAmount.Location = new System.Drawing.Point(456, 318);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(111, 20);
            this.lblAmount.TabIndex = 20;
            this.lblAmount.Text = "Total Amount：";
            this.lblAmount.Click += new System.EventHandler(this.lblAmount_Click);
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDescription.Location = new System.Drawing.Point(456, 74);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(61, 20);
            this.lblDescription.TabIndex = 21;
            this.lblDescription.Text = "UserID:";
            // 
            // RadioNormal
            // 
            this.RadioNormal.AutoSize = true;
            this.RadioNormal.Checked = true;
            this.RadioNormal.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RadioNormal.Location = new System.Drawing.Point(15, 26);
            this.RadioNormal.Name = "RadioNormal";
            this.RadioNormal.Size = new System.Drawing.Size(82, 24);
            this.RadioNormal.TabIndex = 26;
            this.RadioNormal.TabStop = true;
            this.RadioNormal.Text = "Normal";
            this.RadioNormal.UseVisualStyleBackColor = true;
            this.RadioNormal.CheckedChanged += new System.EventHandler(this.RadioNormal_CheckedChanged);
            // 
            // RadioUrgent
            // 
            this.RadioUrgent.AutoSize = true;
            this.RadioUrgent.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RadioUrgent.Location = new System.Drawing.Point(133, 26);
            this.RadioUrgent.Name = "RadioUrgent";
            this.RadioUrgent.Size = new System.Drawing.Size(80, 24);
            this.RadioUrgent.TabIndex = 27;
            this.RadioUrgent.Text = "Urgent";
            this.RadioUrgent.UseVisualStyleBackColor = true;
            this.RadioUrgent.CheckedChanged += new System.EventHandler(this.RadioUrgent_CheckedChanged);
            // 
            // cbUserID
            // 
            this.cbUserID.FormattingEnabled = true;
            this.cbUserID.Location = new System.Drawing.Point(454, 97);
            this.cbUserID.Name = "cbUserID";
            this.cbUserID.Size = new System.Drawing.Size(275, 28);
            this.cbUserID.TabIndex = 29;
            this.cbUserID.SelectedIndexChanged += new System.EventHandler(this.cbUserID_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RadioNormal);
            this.groupBox1.Controls.Add(this.RadioUrgent);
            this.groupBox1.Location = new System.Drawing.Point(454, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 60);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // UserDetail
            // 
            this.UserDetail.AutoSize = true;
            this.UserDetail.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserDetail.Location = new System.Drawing.Point(456, 231);
            this.UserDetail.Name = "UserDetail";
            this.UserDetail.Size = new System.Drawing.Size(61, 60);
            this.UserDetail.TabIndex = 31;
            this.UserDetail.Text = "Name: \r\nEmail:\r\nPhone:";
            this.UserDetail.Click += new System.EventHandler(this.UserDetail_Click);
            // 
            // OrderService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.UserDetail);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbUserID);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.btnCancel2);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.GroupService);
            this.Controls.Add(this.lblT4);
            this.Name = "OrderService";
            this.Text = "OrderService";
            this.Load += new System.EventHandler(this.OrderService_Load);
            this.GroupService.ResumeLayout(false);
            this.GroupService.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblT4;
        private GroupBox GroupService;
        private Button btnOk;
        private Button btnCancel2;
        private Label lblAmount;
        private Label lblDescription;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private RadioButton RadioNormal;
        private RadioButton RadioUrgent;
        private RadioButton radioBtn2;
        private RadioButton radioBtn1;
        private RadioButton radioBtn3;
        private ComboBox cbUserID;
        private RadioButton radioBtn4;
        private RadioButton radioBtn8;
        private RadioButton radioBtn7;
        private RadioButton radioBtn6;
        private RadioButton radioBtn5;
        private GroupBox groupBox1;
        private Label UserDetail;
    }
}