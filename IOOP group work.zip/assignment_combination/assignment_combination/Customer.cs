﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Customer
    {
        private string UserName = "";
        private string Email = "";
        private string Phone = "";
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        SqlConnection con2 = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public Customer(string n, string e, string p)
        {
            UserName = n;
            Email = e;
            Phone = p;
        }

        public Customer(string name)
        {
            UserName=name;
        }

        public Customer()
        {

        }

        public string RegisterNewCustomer()
        {
            string status = "";
            string newCustomerID = customerUserIDGenerator();
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into CustomerData (UserID,UserName,Email,Phone)values(@UserID,@UserName,@Email,@Phone)", con);
            cmd.Parameters.AddWithValue("@UserID", newCustomerID);
            cmd.Parameters.AddWithValue("@UserName", UserName);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Phone", Phone);
            SqlCommand cmd2 = new SqlCommand("insert into UserData(UserName,Password,Role) values(@UserID,'123456','Customer')", con);
            cmd2.Parameters.AddWithValue("UserID", newCustomerID);
            cmd2.ExecuteNonQuery();

            int i = cmd.ExecuteNonQuery();

            if (i != 0)
            {
                status = "Welcome " + UserName + "\nYour User ID is " + newCustomerID + "\nYour default password is 123456";
            }
            else
                status = "Failed to register. Please try again.";
            con.Close();
            return status;
        }

        private string customerUserIDGenerator()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from CustomerData",con);
            int count = (Convert.ToInt32(cmd.ExecuteScalar().ToString())) + 1;
            string newUserID = "";
            if (count < 10 && count > 0)
                newUserID = "Customer00" + count;
            else if (count < 100 && count > 0)
                newUserID = "Customer0" + count;
            else if (count >= 1000)
                newUserID = "Customer" + count;

            con.Close();
            return newUserID;

        }
        public ArrayList viewAllCustomerID()
        {
            ArrayList c = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserID from CustomerData where UserID like 'Customer%'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
                c.Add(rd.GetString(0));
            con.Close();
            return c;
        }

        public string viewCustomerDetail(string str)
        {
            con2.Open();
            SqlCommand cmd = new SqlCommand("select " + str + " from CustomerData where UserID = '" + UserName + "'", con2);
            string detail = cmd.ExecuteScalar().ToString();
            con2.Close();
            return detail;
        }

        public string viewReceptionistDetail(string str)
        {
            con2.Open();
            SqlCommand cmd = new SqlCommand("select " + str + " from Receptionist where userID = '" + UserName + "'", con2);
            string detail = cmd.ExecuteScalar().ToString();
            con2.Close();
            return detail;
        }

    }
}
