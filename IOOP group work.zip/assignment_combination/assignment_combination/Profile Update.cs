﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupAssignment
{
   
    public partial class ProfileUpdate : Form
    {
        public static string name;
        public ProfileUpdate()
        {
            InitializeComponent();
        }

        public ProfileUpdate(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void ProfileUpdate_Load(object sender, EventArgs e)
        {
            Customer2 obj1 = new Customer2(name);
            // read the sqlcommand then show the user and customer data while this form are loaded.
            Customer2.ViewProfile(obj1);
            txtemail.Text = obj1.Email;
            txtphone.Text = obj1.Phone;
            Customer2.ViewPassword(obj1);
            txtpass.Text = obj1.Password;
        }

        private void btnUpdateEP_Click_1(object sender, EventArgs e)
        {
            // update password, email, phone number
            Customer2 obj1 = new Customer2(name);
            MessageBox.Show(obj1.UpdateProfile(txtemail.Text, txtphone.Text, txtpass.Text));
        }
    }
}
