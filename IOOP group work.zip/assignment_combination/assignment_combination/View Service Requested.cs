﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Collections;

namespace Technician_IOOP
{
    public partial class ViewServiceRequested : Form
    {
        public static string Username;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public ViewServiceRequested(string UN)
        {
            InitializeComponent();
            Username = UN;
        }
        public ViewServiceRequested()
        {
            InitializeComponent();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Service, Status, PickupDate, Description from [report] where OrderID = '" + cmbService.SelectedItem + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                txtDescription.Text = rd["Description"].ToString();
                txtStatus.Text = rd["Status"].ToString();
                txtService.Text = rd["Service"].ToString();
                dtpPickupDate.Text = rd["PickupDate"].ToString();
            }
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCustomerName_TextChanged(object sender, EventArgs e)
        {

        }

        private void ViewServiceRequested_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select OrderID from report where Status != 'complete'" , con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                cmbService.Items.Add(rd["OrderID"].ToString());
                cmbService.DisplayMember = (rd["OrderID"].ToString());
                cmbService.ValueMember = (rd["OrderID"].ToString());
            }
            con.Close();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            String status;
            con.Open();
            SqlCommand cmd = new SqlCommand("update [report] set PickupDate = '" + dtpPickupDate.Value + "',Description = '" + txtDescription.Text + "',Status = '" + txtStatus.Text + "'where OrderID = '" + cmbService.SelectedItem + "'", con);
            int i = cmd.ExecuteNonQuery();
            if ((i != 0))
            {
                status = "Update Successfully.";
            }
            else
            {
                status = "Unable to update.";
            }
            con.Close();
            MessageBox.Show(status);
        }
    }
}
