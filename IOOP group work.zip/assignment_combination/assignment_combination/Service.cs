﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Service
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public Service()
        {

        }
        public string serviceAmount(string a, string b)
        {
            string Amount = "0";
            if (b == "Normal")
            {
                if (a == "Remove virus, malware or spyware")
                    Amount = "50";
                else if (a == "Troubleshot and fix computer running slow")
                    Amount = "60";
                else if (a == "Laptop screen replacement")
                    Amount = "380";
                else if (a == "Laptop keyboard replacement")
                    Amount = "160";
                else if (a == "Laptop battery replacement")
                    Amount = "180";
                else if (a == "Operating System Format and Installation")
                    Amount = "100";
                else if (a == "Data backup and recovery")
                    Amount = "80";
                else if (a == "Internet connectivity issues")
                    Amount = "70";
            }
            else if (b == "Urgent")
            {
                if (a == "Remove virus, malware or spyware")
                    Amount = "80";
                else if (a == "Troubleshot and fix computer running slow")
                    Amount = "90";
                else if (a == "Laptop screen replacement")
                    Amount = "430";
                else if (a == "Laptop keyboard replacement")
                    Amount = "200";
                else if (a == "Laptop battery replacement")
                    Amount = "210";
                else if (a == "Operating System Format and Installation")
                    Amount = "150";
                else if (a == "Data backup and recovery")
                    Amount = "130";
                else if (a == "Internet connectivity issues")
                    Amount = "100";
            }

            return Amount;

        }
        private static string serviceIDGenerator()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from report", con);
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString()) + 1;
            string newServiceID = "";

            if (count < 10 && count > 0)
                newServiceID = "S000" + count;
            else if (count < 100 && count > 0)
                newServiceID = "S00" + count;
            else if (count < 1000 && count > 0)
                newServiceID = "S0" + count;
            else if (count >= 1000)
                newServiceID = "S" + count;

            con.Close();

            return newServiceID;
        }

        public string submitService(string SubmittedUserID, string Service, string Urgency)
        {
            string status = "";
            string serviceID = serviceIDGenerator();
            DateTime submittedDate = DateTime.Now;

            string estimatedFee = serviceAmount(Service, Urgency);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into report(OrderID,UserID,Service,Urgency,Price,Description,PickupDate,Status,payment) values(@OrderID,@UserID,@Service,@Urgency,@Price,@Description,@PickupDate,@Status,@payment)", con);
            cmd.Parameters.AddWithValue("@OrderID", serviceID);
            cmd.Parameters.AddWithValue("@UserID", SubmittedUserID);
            cmd.Parameters.AddWithValue("@Service", Service);
            cmd.Parameters.AddWithValue("@Urgency", Urgency);
            cmd.Parameters.AddWithValue("@Price", estimatedFee);
            cmd.Parameters.AddWithValue("@Description", "-");
            cmd.Parameters.AddWithValue("@PickupDate", submittedDate);
            cmd.Parameters.AddWithValue("@Status", "pending");
            cmd.Parameters.AddWithValue("@payment", "Unpaid");
            cmd.ExecuteNonQuery();
            status = "Service submitted for " + SubmittedUserID + "\nService ID: " + serviceID;

            con.Close();

            return status;
        }

        public ArrayList viewAllOrderID()
        {
            ArrayList a = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select OrderID from report where Payment = 'Unpaid'", con);
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
                a.Add(r.GetString(0));
            con.Close();
            return a;
        }

        public string findCustomer(string OrderID)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select UserID from report where OrderID = '" + OrderID + "'", con);
            string id = cmd.ExecuteScalar().ToString();
            con.Close();
            return id;
        }

        public string viewinform(string UserID, string str)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select " + str + " from CustomerData where UserID = '" + UserID + "'", con);
            string inform = cmd.ExecuteScalar().ToString();
            con.Close();
            return inform;
        }

        public string viewServiceDetail(string ServiceID, string s)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select " + s + " from report where OrderID = '" + ServiceID + "'", con);
            string service = cmd.ExecuteScalar().ToString();
            con.Close();
            return service;
        }

        public string payService(string ServiceID)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update report set Payment = 'paid' where OrderID = '" + ServiceID + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            string status = "Payment from service" + ServiceID + "received";
            return status;
        }
    }

}   
            
