﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupAssignment
{
    public partial class CustomerHome : Form
    {
        public static string name; 

        public CustomerHome()
        {
            InitializeComponent();
        }

        public CustomerHome(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            //close the current form then open the previous form. 
            this.Close();
            /*frmLogin obj1 = new frmLogin();
            obj1.Show();*/
        }

        private void CustomerHome_Load(object sender, EventArgs e)
        {
            lblName.Text = name;
            Customer2 obj1 = new Customer2(name);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //close the application
            Application.Exit();
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            ServiceDetails sd = new ServiceDetails(name);
            sd.ShowDialog();
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            ProfileUpdate pu = new ProfileUpdate(name);
            pu.ShowDialog();
        }
    }
}
