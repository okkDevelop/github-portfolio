﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Technician_IOOP
{
    public partial class UpdateProfile1 : Form
    {
        public static string Username;

        public UpdateProfile1()
        {
            InitializeComponent();
        }
        public UpdateProfile1(string UN)
        {
            InitializeComponent();
            Username = UN;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateProfile_Load(object sender, EventArgs e)
        {
            Technician obj1 = new Technician(Username);
            Technician.ViewProfile(obj1);
            txtEmail.Text = obj1.Email;
            txtPhone.Text = obj1.Phone_number;
            txtPassword.Text = obj1.Password;
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Technician obj1 = new Technician(Username);
            try
            {
                int phonenum = Convert.ToInt32(txtPhone.Text);
                string email = txtEmail.Text;
                string password = txtPassword.Text;
                if (password.Length < 0)
                {
                    MessageBox.Show("Please reenter your password");
                }
                else
                {
                    if (email.Contains("@") && email.Contains("."))
                    {
                        MessageBox.Show(obj1.UpdateInfo(txtEmail.Text, txtPhone.Text, txtPassword.Text));
                    }
                    else
                    {
                        MessageBox.Show("Invalid Email");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Invalid Phone Number");
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}