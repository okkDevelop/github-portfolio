﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class OrderService : Form
    {
        public string loggedUserID;
        private string selectedService;
        private string urgency;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public OrderService()
        {
            InitializeComponent();
        }

        public OrderService(string u)
        {
            InitializeComponent();
            loggedUserID = u;
        }

        private void btnCancel2_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
            a.ShowDialog();
            this.Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (cbUserID.SelectedIndex != -1 )
            {
                if (radioBtn1.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn2.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn3.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn4.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn5.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn6.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn7.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else if (radioBtn8.Checked == true)
                {
                    this.Hide();
                    Service obj1 = new Service();
                    string status = obj1.submitService(cbUserID.SelectedItem.ToString(), selectedService, urgency);
                    MessageBox.Show(status);
                    ReceptionistMenu a = new ReceptionistMenu(loggedUserID);
                    a.ShowDialog();
                    this.Close();
                }
                else 
                {
                    MessageBox.Show("Pls Select Service");
                }
            }
            else
            {
                MessageBox.Show("Invalid Error");
            }
        }

        private void OrderService_Load(object sender, EventArgs e)
        {
            ArrayList CustomerUserID = new ArrayList();
            Customer obj1 = new Customer();
            CustomerUserID = obj1.viewAllCustomerID();
            foreach (var item in CustomerUserID)
                cbUserID.Items.Add(item);
            urgency = "Normal";
        }

        private void lblAmount_Click(object sender, EventArgs e)
        {

        }

        private void radioBtn1_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn1.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);
        }

        private void radioBtn2_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn2.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void radioBtn3_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn3.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void radioBtn4_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn4.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void radioBtn5_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn5.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void radioBtn6_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn6.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void radioBtn7_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn7.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void radioBtn8_CheckedChanged(object sender, EventArgs e)
        {
            selectedService = radioBtn8.Text;
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);

        }

        private void RadioNormal_CheckedChanged(object sender, EventArgs e)
        {
            if (RadioNormal.Checked)
                urgency = "Normal";
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);
        }

        private void RadioUrgent_CheckedChanged(object sender, EventArgs e)
        {
            if (RadioUrgent.Checked)
                urgency = "Urgent";
            Service obj2 = new Service();
            lblAmount.Text = "Total amount:" + obj2.serviceAmount(selectedService, urgency);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void cbUserID_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer obj3 = new Customer(cbUserID.SelectedItem.ToString());
            string Name = obj3.viewCustomerDetail("UserName");
            string Email = obj3.viewCustomerDetail("Email");
            string Phone = obj3.viewCustomerDetail("Phone");
            UserDetail.Text = "Name = " + Name + "\nEmail = " + Email + "\nPhone = " + Phone;
        }

        private void UserDetail_Click(object sender, EventArgs e)
        {
            
        }
    }
}
