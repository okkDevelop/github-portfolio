﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;

namespace Technician_IOOP
{
    internal class Technician
    {
        private string name;
        private string phone_Number;
        private string email;
        private string Username;
        private string password;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Email { get => email; set => email = value; }
        public string Phone_number { get => phone_Number; set => phone_Number = value; }
        public string Password { get => password; set => password = value; }

        public Technician(string UN, string EM, string PN, string PW)
        {
            Username = UN;
            email = EM;
            phone_Number = PN;
            password = PW;
        }

        public Technician(string UN)
        {
            Username = UN;
        }
        public static void TechUpdate(string UN)
        {
            UpdateProfile1 UP = new UpdateProfile1(UN);
            UP.ShowDialog();
        }
        public static void ViewService(string UN)
        {
            ViewServiceRequested VSR = new ViewServiceRequested(UN);
            VSR.ShowDialog();
        }
        public static void ViewProfile(Technician object1)
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select * from [Technician] where Username= '" + object1.Username + "'", con);
            SqlCommand cmd = new SqlCommand("select * from [Technician] where userID= '" + object1.Username + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                object1.Username = rd.GetString(4);
                object1.Email = rd.GetString(3);
                object1.Phone_number = rd.GetString(2);
            }
            con.Close();
            con.Open();
            //SqlCommand cmd2 = new SqlCommand("select * from [UserId] where Username= '" + object1.Username + "'", con);
            SqlCommand cmd2 = new SqlCommand("select * from [UserData] where UserName= '" + object1.Username + "'", con);
            SqlDataReader rd2 = cmd2.ExecuteReader();
            while (rd2.Read())
            {
                object1.password = rd2.GetString(2);
            }
            con.Close();
        }
        public string UpdateInfo(string EM, string PN, string PW)
        {
            string status;
            con.Open();

            Password = PW;
            Email = EM;
            phone_Number = PN;

            SqlCommand cmd = new SqlCommand("update [Technician] set Email = '" + Email + "',phone_number = '" + phone_Number + "'where UserID = '" + Username + "'", con);
            SqlCommand cmd2 = new SqlCommand("update [UserData] set Password = '" + password + "'where UserName = '" + Username + "'", con);
            int i = cmd.ExecuteNonQuery();
            int i2 = cmd2.ExecuteNonQuery();
            if ((i != 0) && (i2 != 0))
            {
                status = "Update Successfully.";
            }
            else
            {
                status = "Unable to update.";
            }
            con.Close();
            return status;
        }
    }
}
