﻿namespace Assignment
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblT5 = new System.Windows.Forms.Label();
            this.lblServiceType = new System.Windows.Forms.Label();
            this.btnPay = new System.Windows.Forms.Button();
            this.btnCancel3 = new System.Windows.Forms.Button();
            this.cbSeviceID = new System.Windows.Forms.ComboBox();
            this.lblDetail = new System.Windows.Forms.Label();
            this.lblDetailInform = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblT5
            // 
            this.lblT5.AutoSize = true;
            this.lblT5.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblT5.Location = new System.Drawing.Point(295, 25);
            this.lblT5.Name = "lblT5";
            this.lblT5.Size = new System.Drawing.Size(197, 49);
            this.lblT5.TabIndex = 6;
            this.lblT5.Text = "Payment";
            // 
            // lblServiceType
            // 
            this.lblServiceType.AutoSize = true;
            this.lblServiceType.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblServiceType.Location = new System.Drawing.Point(99, 122);
            this.lblServiceType.Name = "lblServiceType";
            this.lblServiceType.Size = new System.Drawing.Size(84, 20);
            this.lblServiceType.TabIndex = 8;
            this.lblServiceType.Text = "Service ID";
            // 
            // btnPay
            // 
            this.btnPay.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPay.Location = new System.Drawing.Point(438, 341);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(121, 60);
            this.btnPay.TabIndex = 11;
            this.btnPay.Text = "Pay";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // btnCancel3
            // 
            this.btnCancel3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCancel3.Location = new System.Drawing.Point(639, 341);
            this.btnCancel3.Name = "btnCancel3";
            this.btnCancel3.Size = new System.Drawing.Size(121, 60);
            this.btnCancel3.TabIndex = 12;
            this.btnCancel3.Text = "Back";
            this.btnCancel3.UseVisualStyleBackColor = true;
            this.btnCancel3.Click += new System.EventHandler(this.btnCancel3_Click);
            // 
            // cbSeviceID
            // 
            this.cbSeviceID.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbSeviceID.FormattingEnabled = true;
            this.cbSeviceID.Location = new System.Drawing.Point(232, 119);
            this.cbSeviceID.Name = "cbSeviceID";
            this.cbSeviceID.Size = new System.Drawing.Size(151, 28);
            this.cbSeviceID.TabIndex = 15;
            this.cbSeviceID.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblDetail
            // 
            this.lblDetail.AutoSize = true;
            this.lblDetail.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDetail.Location = new System.Drawing.Point(99, 232);
            this.lblDetail.Name = "lblDetail";
            this.lblDetail.Size = new System.Drawing.Size(0, 20);
            this.lblDetail.TabIndex = 7;
            // 
            // lblDetailInform
            // 
            this.lblDetailInform.AutoSize = true;
            this.lblDetailInform.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDetailInform.Location = new System.Drawing.Point(438, 210);
            this.lblDetailInform.Name = "lblDetailInform";
            this.lblDetailInform.Size = new System.Drawing.Size(129, 63);
            this.lblDetailInform.TabIndex = 14;
            this.lblDetailInform.Text = "Service Type:: \r\nDescription:\r\nFinal Cost:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(99, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "Detail:";
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbSeviceID);
            this.Controls.Add(this.lblDetailInform);
            this.Controls.Add(this.btnCancel3);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.lblServiceType);
            this.Controls.Add(this.lblDetail);
            this.Controls.Add(this.lblT5);
            this.Name = "Payment";
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.Payment_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblT5;
        private Label lblServiceType;
        private Button btnPay;
        private Button btnCancel3;
        private ComboBox cbSeviceID;
        private Label lblDetail;
        private Label lblDetailInform;
        private Label label1;
    }
}