﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Technician_IOOP
{
    public partial class ChoiceSelection1 : Form
    {
        public static string Username;
        public ChoiceSelection1(string UN)
        {
            InitializeComponent();
            Username = UN;
        }
        public ChoiceSelection1()
        {
            InitializeComponent();
        }
        private void btnServiceRequested_Click(object sender, EventArgs e)
        {
            Technician.ViewService(Username);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            Technician.TechUpdate(Username);
        }

        private void ChoiceSelection_Load(object sender, EventArgs e)
        {

        }
    }
}
