﻿namespace admin_assignment
{
    partial class Admin_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpRegister = new System.Windows.Forms.GroupBox();
            this.btnTech = new System.Windows.Forms.Button();
            this.btnRecep = new System.Windows.Forms.Button();
            this.grpView = new System.Windows.Forms.GroupBox();
            this.btnIncome = new System.Windows.Forms.Button();
            this.btnService = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.grpRegister.SuspendLayout();
            this.grpView.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(118, 54);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(233, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "                           ";
            // 
            // grpRegister
            // 
            this.grpRegister.Controls.Add(this.btnTech);
            this.grpRegister.Controls.Add(this.btnRecep);
            this.grpRegister.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpRegister.Location = new System.Drawing.Point(118, 137);
            this.grpRegister.Name = "grpRegister";
            this.grpRegister.Size = new System.Drawing.Size(217, 196);
            this.grpRegister.TabIndex = 1;
            this.grpRegister.TabStop = false;
            this.grpRegister.Text = "Register ";
            // 
            // btnTech
            // 
            this.btnTech.Location = new System.Drawing.Point(32, 120);
            this.btnTech.Name = "btnTech";
            this.btnTech.Size = new System.Drawing.Size(151, 36);
            this.btnTech.TabIndex = 1;
            this.btnTech.Text = "New Technician";
            this.btnTech.UseVisualStyleBackColor = true;
            this.btnTech.Click += new System.EventHandler(this.btnTech_Click);
            // 
            // btnRecep
            // 
            this.btnRecep.Location = new System.Drawing.Point(32, 51);
            this.btnRecep.Name = "btnRecep";
            this.btnRecep.Size = new System.Drawing.Size(151, 36);
            this.btnRecep.TabIndex = 0;
            this.btnRecep.Text = "New Receptionist";
            this.btnRecep.UseVisualStyleBackColor = true;
            this.btnRecep.Click += new System.EventHandler(this.btnRecep_Click);
            // 
            // grpView
            // 
            this.grpView.Controls.Add(this.btnIncome);
            this.grpView.Controls.Add(this.btnService);
            this.grpView.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpView.Location = new System.Drawing.Point(472, 137);
            this.grpView.Name = "grpView";
            this.grpView.Size = new System.Drawing.Size(217, 196);
            this.grpView.TabIndex = 2;
            this.grpView.TabStop = false;
            this.grpView.Text = "Review Report";
            // 
            // btnIncome
            // 
            this.btnIncome.Location = new System.Drawing.Point(43, 114);
            this.btnIncome.Name = "btnIncome";
            this.btnIncome.Size = new System.Drawing.Size(135, 41);
            this.btnIncome.TabIndex = 1;
            this.btnIncome.Text = "Income Report";
            this.btnIncome.UseVisualStyleBackColor = true;
            this.btnIncome.Click += new System.EventHandler(this.btnIncome_Click);
            // 
            // btnService
            // 
            this.btnService.Location = new System.Drawing.Point(43, 51);
            this.btnService.Name = "btnService";
            this.btnService.Size = new System.Drawing.Size(138, 41);
            this.btnService.TabIndex = 0;
            this.btnService.Text = "Service Report";
            this.btnService.UseVisualStyleBackColor = true;
            this.btnService.Click += new System.EventHandler(this.btnService_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnQuit.Location = new System.Drawing.Point(353, 360);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(104, 34);
            this.btnQuit.TabIndex = 3;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // Admin_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.grpView);
            this.Controls.Add(this.grpRegister);
            this.Controls.Add(this.lblTitle);
            this.Name = "Admin_Form";
            this.Text = "Admin_Form";
            this.Load += new System.EventHandler(this.Admin_Form_Load);
            this.grpRegister.ResumeLayout(false);
            this.grpView.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private GroupBox grpRegister;
        private Button btnTech;
        private Button btnRecep;
        private GroupBox grpView;
        private Button btnIncome;
        private Button btnService;
        private Button btnQuit;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}