﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;

namespace GroupAssignment
{
    internal class Customer2
    {
        //For update profile
        private string email;
        private string phone;
        private string username;
        private string password;
        //-----
        //For service change
        private string price;
        private DateTime pickupDate;
        private string description;
        private string urgency;
        private string service;
        private string orderID;
        //-----


        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Email { get => email; set => email = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Price { get => price; set => price = value; }
        public DateTime PickupDate { get => pickupDate; set => pickupDate = value; }
        public string Description { get => description; set => description = value; }
        public string Service { get => service; set => service = value; }
        public string OrderID { get => orderID; set => orderID = value; }
        public string Urgency { get => urgency; set => urgency = value; }

        public Customer2(string n, string e, string p)
        {
            username = n;
            email = e;
            phone = p;
        }

        public Customer2(string name)
        {
            username = name;
        }



        // For update profile 

        public static void ViewProfile(Customer2 o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from CustomerData where UserName ='" + o1.Username + "'", con);
            SqlDataReader cd = cmd.ExecuteReader();
            while (cd.Read())
            {
                o1.Email = cd.GetString(3);
                o1.Phone = cd.GetString(4);
            }
            con.Close();
        }

        public static void ViewPassword(Customer2 o1)
        {
            con.Open();
            SqlCommand tmd = new SqlCommand("select * from UserData where UserName ='" + o1.Username + "'", con);
            SqlDataReader td = tmd.ExecuteReader();
            while (td.Read())
            {
                o1.Password = td.GetString(2);
            }
            con.Close();
        }

        public string UpdateProfile(string e, string pn, string p)
        {
            string status;
            con.Open();
            phone = pn;
            email = e;
            password = p;
            SqlCommand cmd = new SqlCommand("update CustomerData set Phone='" + phone + "',Email='" + email + "' where UserID ='" + username + "'", con);
            SqlCommand tmd = new SqlCommand("update UserData set Password='" + password + "' where UserName ='" + username + "'", con);
            tmd.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Update Successful.";
            }
            else
                status = "Unable to Update.";
            con.Close();
            return status;
        }

        //For service change.
        public string ServiceChange(string s, string u, string p)
        {
            string status;
            con.Open();
            service = s;
            urgency = u;
            price = p;

            SqlCommand cmd3 = new SqlCommand("update report set Service='" + service + "',Urgency='" + urgency + "' where UserID ='" + username + "'", con);
            int i = cmd3.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Update successfully." + "\n" + "\n" + "We will notify our technician as soon as posible, thank you for your patience.";
            }
            else
                status = "Unable to update !!!";
            con.Close();
            return status;
        }

        public static void ViewService(Customer2 o3)
        {
            con.Open();
            SqlCommand cmd4 = new SqlCommand("select * from report where UserID ='" + o3.Username + "'", con);
            SqlDataReader rd2 = cmd4.ExecuteReader();
            if (rd2.Read())
            {
                o3.OrderID = rd2.GetString(1);
                o3.Service = rd2.GetString(3);
                o3.Price = rd2.GetString(5);
                o3.Description = rd2.GetString(6);
                o3.PickupDate = rd2.GetDateTime(7);
                o3.Urgency = rd2.GetString(4);
            }
            else
            {
                MessageBox.Show("There's no Order detected from your's Account." + "\n" + "Please register at the Reception counter.");
            }             
            con.Close();
        }
    }
}
